// --- Recipe & Suggestions Data ---
let recipeMetadata = [];
let cart = [];
let isProcessing = false;

// --- DOM Elements ---
const dishInput = document.getElementById('dishInput');
const resultsGrid = document.getElementById('resultsGrid');
const cartItemsContainer = document.getElementById('cartItems');
const cartCount = document.querySelector('.cart-count');
const cartTotal = document.getElementById('cartTotal');
const totalSavings = document.getElementById('totalSavings');
const cartSidebar = document.getElementById('cartSidebar');
const cartToggle = document.getElementById('cartToggle');
const closeCart = document.getElementById('closeCart');
const toast = document.getElementById('toast');
const profileTrigger = document.getElementById('profileTrigger');
const profileMenu = document.getElementById('profileMenu');

// --- Initialization ---
async function initRecipeData() {
    try {
        const response = await fetch('https://cosylab.iiitd.edu.in/recipedb/static/metadata.json').catch(() => null);
        if (response && response.ok) {
            const data = await response.json();
            const items = data.ditems ? data.ditems.flatMap(item => item.links) : [];
            recipeMetadata = [...new Set(items)].slice(0, 1000);
        } else {
            throw new Error("Local/CORS block");
        }
    } catch (e) {
        console.warn("RecipeDB metadata fetch failed (CORS or Network), using robust fallbacks.");
        recipeMetadata = ["Butter Chicken", "Sushi", "Pasta Carbonara", "Tacos", "Pizza", "Biryani", "Paneer Tikka", "Burger", "Salad", "Steak", "Noodles", "Dim Sum"];
    }
    updateTrendingTags();
}

function updateTrendingTags() {
    const trendingDiv = document.querySelector('.trending');
    if (!trendingDiv || recipeMetadata.length < 5) return;

    const randomTags = [...recipeMetadata].sort(() => 0.5 - Math.random()).slice(0, 6);
    const label = trendingDiv.querySelector('span') || document.createElement('span');
    label.innerText = "Trending:";
    trendingDiv.innerHTML = "";
    trendingDiv.appendChild(label);

    randomTags.forEach(tagName => {
        const btn = document.createElement('button');
        btn.className = 'tag';
        btn.innerText = tagName;
        btn.onclick = () => {
            dishInput.value = tagName;
            processDish(false);
        };
        trendingDiv.appendChild(btn);
    });
}

// --- Store Data ---
const storePrices = {
    "Chicken Breast": [{ store: "Blinkit", price: 8.20, best: true }, { store: "Instamart", price: 8.90 }],
    "Tomato Puree": [{ store: "Instamart", price: 1.25, best: true }, { store: "Blinkit", price: 1.50 }],
    "Heavy Cream": [{ store: "Blinkit", price: 2.80, best: true }, { store: "Instamart", price: 3.00 }],
    "default": [{ store: "BigBasket", price: 2.50 }, { store: "Blinkit", price: 2.30, best: true }, { store: "Instamart", price: 2.60 }]
};

function getBestPrice(ingredient) {
    const prices = storePrices[ingredient] || storePrices["default"];
    return prices.reduce((min, p) => p.price < min.price ? p : min, prices[0]);
}

function getAllPrices(ingredient) {
    return storePrices[ingredient] || storePrices["default"];
}

// --- API Integration ---
async function fetchRecipeFromAPI(dishName) {
    try {
        const response = await fetch(`https://www.themealdb.com/api/json/v1/1/search.php?s=${encodeURIComponent(dishName)}`);
        const data = await response.json();
        if (data.meals && data.meals.length > 0) {
            const meal = data.meals[0];
            const ingredients = [];
            for (let i = 1; i <= 20; i++) {
                const ing = meal[`strIngredient${i}`];
                if (ing && ing.trim()) ingredients.push(ing.trim());
            }
            return { name: meal.strMeal, ingredients: ingredients, image: meal.strMealThumb };
        }
    } catch (e) { console.error("MealDB Error:", e); }
    return null;
}

const fallbackImages = {
    "egg": "https://images.unsplash.com/photo-1582722872445-44c5c1f0c8a7?w=200&q=80",
    "milk": "https://images.unsplash.com/photo-1550583726-226ff2259b3a?w=200&q=80",
    "flour": "https://images.unsplash.com/photo-1509440159596-0249088772ff?w=200&q=80",
    "chicken": "https://images.unsplash.com/photo-1604503468506-a8da13d82791?w=200&q=80",
    "tomato": "https://images.unsplash.com/photo-1518977676601-b53f82aba655?w=200&q=80",
    "onion": "https://images.unsplash.com/photo-1508747703725-719777637510?w=200&q=80",
    "garlic": "https://images.unsplash.com/photo-1540148426945-6cf22a6b2383?w=200&q=80",
    "salt": "https://images.unsplash.com/photo-1554522437-12347bd78082?w=200&q=80",
    "pepper": "https://images.unsplash.com/photo-1506368249639-73a05d6f6488?w=200&q=80",
    "oil": "https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?w=200&q=80",
    "butter": "https://images.unsplash.com/photo-1589985270826-4b7bb135bc9d?w=200&q=80",
    "sauce": "https://images.unsplash.com/photo-1472476443507-c7a5948772fc?w=200&q=80"
};

async function fetchProductFromOFF(ingredient) {
    try {
        const response = await fetch(`https://world.openfoodfacts.org/cgi/search.pl?search_terms=${encodeURIComponent(ingredient)}&search_simple=1&action=process&json=1&page_size=5`);
        const data = await response.json();
        const product = data.products && data.products.length > 0 ?
            (data.products.find(p => p.image_front_url) || data.products.find(p => p.image_url) || data.products[0]) : null;

        // Categorical fallback logic
        let image = product?.image_front_url || product?.image_url || product?.image_small_url || null;
        if (!image) {
            const lower = ingredient.toLowerCase();
            const key = Object.keys(fallbackImages).find(k => lower.includes(k));
            image = key ? fallbackImages[key] : 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200&q=80';
        }

        return {
            name: product?.product_name || ingredient,
            image: image,
            nutriscore: product?.nutriscore_grade || 'unknown',
            brand: product?.brands || 'Generic'
        };
    } catch (e) {
        console.error("OFF Error:", e);
        return { name: ingredient, image: 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200&q=80', nutriscore: 'unknown', brand: 'Generic' };
    }
}

const ingredientPool = {
    "asian": ["Soy Sauce", "Ginger", "Sesame Oil", "Rice Noodles", "Tofu"],
    "italian": ["Olive Oil", "Basil", "Parmesan", "Pasta", "Garlic"],
    "mexican": ["Tortillas", "Avocado", "Lime", "Black Beans", "Cumin"],
    "indian": ["Garam Masala", "Ghee", "Basmati Rice", "Turmeric", "Coriander"],
    "basic": ["Salt", "Pepper", "Onion", "Garlic", "Oil", "Eggs", "Milk"]
};

function generateSmartIngredients(dishName) {
    const name = dishName.toLowerCase();
    let pool = ingredientPool.basic;
    if (name.includes("curry") || name.includes("masala")) pool = ingredientPool.indian;
    else if (name.includes("pasta") || name.includes("pizza")) pool = ingredientPool.italian;
    else if (name.includes("taco") || name.includes("mexican")) pool = ingredientPool.mexican;
    else if (name.includes("fry") || name.includes("noodle")) pool = ingredientPool.asian;

    const ings = [...pool].sort(() => 0.5 - Math.random()).slice(0, 5);
    const basics = [...ingredientPool.basic].sort(() => 0.5 - Math.random()).slice(0, 3);
    return [...new Set([...ings, ...basics])].slice(0, 8);
}

// --- Fuzzy Search ---
function findFuzzyMatch(dish) {
    if (!recipeMetadata.length) return null;
    const normalized = dish.toLowerCase().trim();
    return recipeMetadata.find(item => item.toLowerCase() === normalized) ||
        recipeMetadata.find(item => item.toLowerCase().includes(normalized)) ||
        recipeMetadata.find(item => normalized.includes(item.toLowerCase()));
}

// --- Main Search Logic ---
async function processDish(autoAdd = false) {
    const rawDish = dishInput.value.trim();
    if (!rawDish || isProcessing) return;

    const safetyTimeout = setTimeout(() => { if (isProcessing) isProcessing = false; }, 30000);

    try {
        isProcessing = true;
        resultsGrid.innerHTML = `<div class="processing-loader" style="grid-column: 1/-1; text-align: center; padding: 3rem;"><i data-lucide="loader-2" class="spin"></i><p>Analyzing ${rawDish}...</p></div>`;
        lucide.createIcons();

        // 1. Fetch Recipe
        let apiMeal = await fetchRecipeFromAPI(rawDish);
        if (!apiMeal) {
            const alternative = rawDish.toLowerCase().endsWith('s') ? rawDish.slice(0, -1) : rawDish + 's';
            apiMeal = await fetchRecipeFromAPI(alternative);
        }
        if (!apiMeal) {
            const fuzzy = findFuzzyMatch(rawDish);
            if (fuzzy) apiMeal = await fetchRecipeFromAPI(fuzzy);
        }

        let ingredients = apiMeal ? apiMeal.ingredients : generateSmartIngredients(rawDish);

        // UI Animation
        const steps = ['step1', 'step2', 'step3'];
        for (const id of steps) {
            const el = document.getElementById(id);
            if (el) el.classList.add('active');
            await new Promise(r => setTimeout(r, 600));
        }

        resultsGrid.innerHTML = "";
        const fetchSubset = ingredients.slice(0, 15);
        const detailsList = await Promise.all(fetchSubset.map(ing => fetchProductFromOFF(ing)));

        fetchSubset.forEach((ing, idx) => {
            const best = getBestPrice(ing);
            const all = getAllPrices(ing);
            const offInfo = detailsList[idx];
            const imagePath = offInfo?.image || 'https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=200&q=80';

            const card = document.createElement('div');
            card.className = 'ingredient-card';
            card.innerHTML = `
                <div class="card-img" style="background-image: url('${imagePath}'); background-size: cover;">
                    <div class="price-badge">$${best.price.toFixed(2)}</div>
                    ${offInfo ? `<div class="scores-container"><span class="score-badge nutri score-${offInfo.nutriscore}">${offInfo.nutriscore.toUpperCase()}</span></div>` : ''}
                </div>
                <div class="card-content">
                    <h4>${offInfo?.name || ing}</h4>
                    <div class="store-info"><i data-lucide="map-pin"></i><span>Lowest: ${best.store}</span></div>
                    <div class="compare-prices">${all.map(p => `<span class="store-pill ${p.store === best.store ? 'best' : ''}">${p.store}: $${p.price.toFixed(2)}</span>`).join('')}</div>
                    <button class="add-single-btn primary-action-btn" style="width:100%; margin-top:10px;">Add Item</button>
                </div>
            `;

            card.querySelector('.add-single-btn').addEventListener('click', () => {
                addToCart(ing, best, offInfo?.image || imagePath);
                showToast(`Added ${ing} to cart!`);
            });

            resultsGrid.appendChild(card);
            if (autoAdd) addToCart(ing, best, offInfo?.image || imagePath);
        });

        if (fetchSubset.length > 0 && !autoAdd) {
            const banner = document.createElement('div');
            banner.className = 'bulk-add-banner';
            banner.style.gridColumn = "1/-1";
            banner.innerHTML = `<div><h3 style="margin:0; font-size:1.1rem;">Found ${fetchSubset.length} ingredients</h3><p style="margin:0; opacity:0.8;">Total: $${fetchSubset.reduce((a, b) => a + getBestPrice(b).price, 0).toFixed(2)}</p></div><button id="addAllToCart" class="search-btn primary" style="width:auto; height:auto;">Add All to Cart</button>`;
            resultsGrid.insertBefore(banner, resultsGrid.firstChild);
            document.getElementById('addAllToCart').addEventListener('click', () => {
                fetchSubset.forEach((ing, i) => addToCart(ing, getBestPrice(ing), detailsList[i]?.image));
                showToast("All items added!");
            });
        }

        lucide.createIcons();
        showToast(autoAdd ? "Added to cart!" : "Found ingredients!");
        dishInput.value = "";
    } catch (e) {
        console.error(e);
        showToast("Search failed.");
    } finally {
        isProcessing = false;
        clearTimeout(safetyTimeout);
        setTimeout(() => ['step1', 'step2', 'step3'].forEach(id => document.getElementById(id)?.classList.remove('active')), 5000);
    }
}

// --- Cart Logic ---
function addToCart(name, details, image = null) {
    const existing = cart.find(i => i.name === name);
    if (existing) existing.quantity++;
    else cart.push({ name, price: details.price, store: details.store, quantity: 1, image });
    updateCartUI();
    saveCartToDB();
    if (cartSidebar) cartSidebar.classList.add('open');
}

function updateCartUI() {
    cartItemsContainer.innerHTML = "";
    let total = 0, count = 0, savings = 0;

    if (!cart.length) {
        cartItemsContainer.innerHTML = `<p class="empty-msg">Your cart is empty.</p>`;
    } else {
        cart.forEach(item => {
            total += item.price * item.quantity;
            count += item.quantity;
            savings += (item.price * 0.2);
            const div = document.createElement('div');
            div.className = 'cart-item';
            div.innerHTML = `
                <div class="item-img"><img src="${item.image || 'https://via.placeholder.com/50'}" style="width:100%; height:100%; object-fit:cover;"></div>
                <div class="item-details"><h5>${item.name} x${item.quantity}</h5><p>${item.store}</p></div>
                <div class="item-actions"><span>$${(item.price * item.quantity).toFixed(2)}</span><button onclick="removeFromCart('${item.name}')"><i data-lucide="trash-2"></i></button></div>
            `;
            cartItemsContainer.appendChild(div);
        });
    }
    cartCount.innerText = count;
    cartTotal.innerText = `$${total.toFixed(2)}`;
    totalSavings.innerText = `$${savings.toFixed(2)}`;
    lucide.createIcons();
}

function removeFromCart(name) {
    cart = cart.filter(i => i.name !== name);
    updateCartUI();
    saveCartToDB();
}

function saveCartToDB() {
    const user = JSON.parse(localStorage.getItem('vesto_active_user'));
    if (user) {
        user.cart = cart;
        localStorage.setItem('vesto_active_user', JSON.stringify(user));
        const users = JSON.parse(localStorage.getItem('vesto_users') || '[]');
        const idx = users.findIndex(u => u.email === user.email);
        if (idx !== -1) { users[idx].cart = cart; localStorage.setItem('vesto_users', JSON.stringify(users)); }
    }
}

function showToast(msg) {
    toast.querySelector('span').innerText = msg;
    toast.classList.add('show');
    setTimeout(() => toast.classList.remove('show'), 3000);
}

// --- Initialization & Listeners ---
function initUser() {
    const user = JSON.parse(localStorage.getItem('vesto_active_user'));
    if (user) {
        document.getElementById('userName').innerText = user.email.split('@')[0];
        document.getElementById('userEmail').innerText = user.email;
        cart = user.cart || [];
        updateCartUI();
    }
}

document.addEventListener('DOMContentLoaded', () => {
    initUser();
    initRecipeData();

    document.getElementById('analyzeBtn').onclick = () => processDish(false);
    document.getElementById('dishToCartBtn').onclick = () => processDish(true);

    dishInput.addEventListener('keydown', (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            processDish(true);
        }
    });

    cartToggle.onclick = () => cartSidebar.classList.add('open');
    closeCart.onclick = () => cartSidebar.classList.remove('open');
    document.getElementById('clearCart').onclick = () => { if (confirm("Clear cart?")) { cart = []; updateCartUI(); saveCartToDB(); } };

    profileTrigger.onclick = () => profileMenu.classList.toggle('open');
    document.getElementById('logoutBtn').onclick = () => { localStorage.removeItem('vesto_active_user'); window.location.href = 'login.html'; };
});
