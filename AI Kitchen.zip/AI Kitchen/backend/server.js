const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 5000;

// Middleware
app.use(cors());
app.use(express.json());

// MongoDB Connection
// Replace with your MongoDB URI
const MONGODB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/vestocart';
mongoose.connect(MONGODB_URI)
    .then(() => console.log('MongoDB connected'))
    .catch(err => console.log('MongoDB connection error:', err));

// Inventory Model
const inventorySchema = new mongoose.Schema({
    userId: String,
    product: String,
    quantity: Number, // Percentage 0-100
    purchaseDate: { type: Date, default: Date.now },
    usageEstimate: Number, // Estimated units used per day
    category: String,
    orderHistory: [{
        date: { type: Date, default: Date.now },
        amount: String,
        status: String
    }]
});

const Inventory = mongoose.model('Inventory', inventorySchema);

// Cart Model
const cartSchema = new mongoose.Schema({
    userId: String,
    productId: mongoose.Schema.Types.ObjectId,
    productName: String,
    quantity: { type: Number, default: 1 },
    addedAt: { type: Date, default: Date.now }
});

const Cart = mongoose.model('Cart', cartSchema);

// API Endpoints
app.get('/kitchen-twin/:userId', async (req, res) => {
    try {
        const inventory = await Inventory.find({ userId: req.params.userId });

        // Prediction logic (simple for now)
        const detailedInventory = inventory.map(item => {
            const daysSincePurchase = (new Date() - new Date(item.purchaseDate)) / (1000 * 60 * 60 * 24);
            const remainingQuantity = Math.max(0, item.quantity - (daysSincePurchase * item.usageEstimate));
            const estimatedDaysLeft = item.usageEstimate > 0 ? Math.floor(remainingQuantity / item.usageEstimate) : 30;

            let status = "Full";
            if (remainingQuantity < 25) status = "Low Stock";
            else if (remainingQuantity < 60) status = "Medium";

            return {
                ...item._doc,
                remainingQuantity: Math.round(remainingQuantity),
                status,
                estimated_days_left: estimatedDaysLeft,
                suggestion: remainingQuantity < 30 ? "Add to Smart Cart" : "Sufficient"
            };
        });

        res.json(detailedInventory);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.post('/update-inventory', async (req, res) => {
    const { userId, productId, quantity, amount } = req.body;
    try {
        const item = await Inventory.findById(productId);
        if (!item) return res.status(404).json({ message: 'Item not found' });

        item.quantity = quantity || 100;
        item.purchaseDate = new Date();
        item.orderHistory.push({
            date: new Date(),
            amount: amount || 'Standard Refill',
            status: 'Completed'
        });

        const savedItem = await item.save();
        res.json(savedItem);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

// Cart Endpoints
app.get('/cart/:userId', async (req, res) => {
    try {
        const cartItems = await Cart.find({ userId: req.params.userId });
        res.json(cartItems);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.post('/cart/add', async (req, res) => {
    const { userId, productId, productName } = req.body;
    try {
        let cartItem = await Cart.findOne({ userId, productId });
        if (cartItem) {
            cartItem.quantity += 1;
        } else {
            cartItem = new Cart({ userId, productId, productName });
        }
        await cartItem.save();
        res.status(201).json(cartItem);
    } catch (err) {
        res.status(400).json({ message: err.message });
    }
});

app.delete('/cart/:itemId', async (req, res) => {
    try {
        await Cart.findByIdAndDelete(req.params.itemId);
        res.json({ message: 'Item removed from cart' });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
});

app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});
