// ═══════════════════════════════════════
// VestoCart — Frontend Application
// ═══════════════════════════════════════
// Connects to the backend API at localhost:3000

// Auto-detect API base: same origin when served from backend, fallback for file:// protocol
const API_BASE = window.location.protocol === 'file:'
    ? 'http://localhost:3000'
    : window.location.origin;

// ── Nav scroll effect ──
const nav = document.getElementById('nav');
window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
});

// ── Scroll reveal (Intersection Observer) ──
const revealEls = document.querySelectorAll('.reveal');
const revealObs = new IntersectionObserver((entries) => {
    entries.forEach(e => { if (e.isIntersecting) { e.target.classList.add('visible'); revealObs.unobserve(e.target); } });
}, { threshold: 0.15 });
revealEls.forEach(el => revealObs.observe(el));

// ── Animated counters ──
function animateCounter(el, target, prefix = '', suffix = '') {
    let current = 0;
    const step = Math.max(1, Math.floor(target / 60));
    const timer = setInterval(() => {
        current += step;
        if (current >= target) { current = target; clearInterval(timer); }
        el.textContent = prefix + current.toLocaleString() + suffix;
    }, 25);
}

const counterObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
        if (e.isIntersecting) {
            const count = parseInt(e.target.getAttribute('data-count'));
            if (!count) return;
            const text = e.target.textContent;
            let prefix = '', suffix = '';
            if (text.includes('₹')) prefix = '₹';
            if (text.includes('%')) suffix = '%';
            if (text.includes('K')) suffix = 'K+';
            animateCounter(e.target, count, prefix, suffix);
            counterObs.unobserve(e.target);
        }
    });
}, { threshold: 0.5 });
document.querySelectorAll('[data-count]').forEach(el => counterObs.observe(el));

// ── Hero chart bars ──
function buildHeroChart() {
    const container = document.getElementById('heroChart');
    if (!container) return;
    const values = [35, 50, 40, 65, 55, 75, 60, 80, 70, 90, 85, 95];
    const colors = ['#0c831f', '#66bb6a'];
    values.forEach((v, i) => {
        const bar = document.createElement('div');
        bar.className = 'chart-bar';
        bar.style.height = v + '%';
        bar.style.background = colors[i % 2];
        bar.style.opacity = '0';
        bar.style.animation = `fadeInUp 0.5s ease ${i * 0.05}s forwards`;
        container.appendChild(bar);
    });
}

// ── vestro metric bars animation ──
const metricObs = new IntersectionObserver((entries) => {
    entries.forEach(e => {
        if (e.isIntersecting) {
            const bar = e.target;
            const w = bar.getAttribute('data-width');
            if (w) bar.style.width = w + '%';
            metricObs.unobserve(bar);
        }
    });
}, { threshold: 0.3 });
document.querySelectorAll('.vestro-metric-bar, .gamify-bar').forEach(el => metricObs.observe(el));

// ── Dish-to-Cart interaction ──
const dishInput = document.getElementById('dishInput');
const suggestionItems = document.querySelectorAll('.dish-suggestion-item');
const ingredientList = document.getElementById('ingredientList');

const recipeDB = {
    "Paneer Butter Masala": [
        { name: "Paneer (200g)", brand: "Fresh block", price: "₹89", have: true },
        { name: "Butter (100g)", brand: "Amul salted", price: "₹56", have: true },
        { name: "Tomato Puree (400g)", brand: "Kissan", price: "₹45", have: true },
        { name: "Cream (200ml)", brand: "Amul fresh", price: "₹35", have: false },
        { name: "Garam Masala (50g)", brand: "MDH", price: "₹42", have: false },
        { name: "Kasuri Methi (25g)", brand: "Organic", price: "₹28", have: false }
    ],
    "Chicken Biryani": [
        { name: "Chicken (500g)", brand: "Fresh", price: "₹210", have: false },
        { name: "Basmati Rice (1kg)", brand: "India Gate", price: "₹145", have: true },
        { name: "Onions (500g)", brand: "Fresh", price: "₹25", have: true },
        { name: "Yogurt (200g)", brand: "Amul", price: "₹30", have: false },
        { name: "Biryani Masala (50g)", brand: "Shan", price: "₹65", have: false },
        { name: "Saffron (1g)", brand: "Kashmir", price: "₹120", have: false },
        { name: "Mint Leaves (bunch)", brand: "Organic", price: "₹15", have: true },
        { name: "Ghee (100g)", brand: "Amul", price: "₹58", have: false }
    ],
    "Masala Dosa": [
        { name: "Dosa Batter (500g)", brand: "iD Fresh", price: "₹55", have: false },
        { name: "Potatoes (500g)", brand: "Fresh", price: "₹20", have: true },
        { name: "Onions (250g)", brand: "Fresh", price: "₹12", have: true },
        { name: "Mustard Seeds (50g)", brand: "Organic", price: "₹18", have: false },
        { name: "Curry Leaves (bunch)", brand: "Fresh", price: "₹10", have: true },
        { name: "Oil (200ml)", brand: "Sunflower", price: "₹35", have: true }
    ],
    "Dal Makhani": [
        { name: "Black Urad Dal (250g)", brand: "Tata", price: "₹68", have: false },
        { name: "Rajma (100g)", brand: "Tata", price: "₹35", have: false },
        { name: "Butter (100g)", brand: "Amul", price: "₹56", have: true },
        { name: "Cream (200ml)", brand: "Amul", price: "₹35", have: false },
        { name: "Tomatoes (300g)", brand: "Fresh", price: "₹18", have: true },
        { name: "Ginger Garlic Paste (100g)", brand: "Smith & Jones", price: "₹32", have: false }
    ]
};

function renderIngredients(dishName) {
    if (!ingredientList) return;
    const items = recipeDB[dishName];
    if (!items) return;
    ingredientList.innerHTML = '';
    items.forEach((item, i) => {
        const el = document.createElement('div');
        el.className = 'ingredient-item';
        el.style.opacity = '0';
        el.style.animation = `fadeInUp 0.4s ease ${i * 0.08}s forwards`;
        el.innerHTML = `
      <div class="ingredient-check ${item.have ? 'checked' : ''}">✓</div>
      <span class="ingredient-name">${item.name}</span>
      <span class="ingredient-qty">${item.brand}</span>
      <span class="ingredient-price">${item.price}</span>
    `;
        el.querySelector('.ingredient-check').addEventListener('click', function () {
            this.classList.toggle('checked');
        });
        ingredientList.appendChild(el);
    });
}

if (dishInput) {
    dishInput.addEventListener('input', (e) => {
        const val = e.target.value.toLowerCase();
        suggestionItems.forEach(item => {
            const name = item.getAttribute('data-dish').toLowerCase();
            item.style.display = name.includes(val) ? 'flex' : 'none';
        });
    });
}

suggestionItems.forEach(item => {
    item.addEventListener('click', () => {
        const dish = item.getAttribute('data-dish');
        dishInput.value = dish;
        fetchDishIngredients(dish);
    });
});

// ═══════════════════════════════════════
// API INTEGRATION — Calls Backend at API_BASE
// ═══════════════════════════════════════

async function fetchDishIngredients(dishName) {
    try {
        const res = await fetch(`${API_BASE}/api/dish-to-cart?dish=${encodeURIComponent(dishName)}`);
        if (res.ok) {
            const data = await res.json();
            renderIngredientsFromAPI(data.ingredients);
        } else {
            renderIngredients(dishName);  // fallback to local
        }
    } catch {
        renderIngredients(dishName);  // fallback to local
    }
}

function renderIngredientsFromAPI(items) {
    if (!ingredientList || !items) return;
    ingredientList.innerHTML = '';
    items.forEach((item, i) => {
        const el = document.createElement('div');
        el.className = 'ingredient-item';
        el.style.opacity = '0';
        el.style.animation = `fadeInUp 0.4s ease ${i * 0.08}s forwards`;
        el.innerHTML = `
      <div class="ingredient-check ${item.inKitchen ? 'checked' : ''}">✓</div>
      <span class="ingredient-name">${item.name}</span>
      <span class="ingredient-qty">${item.brand}</span>
      <span class="ingredient-price">₹${item.price}</span>
    `;
        el.querySelector('.ingredient-check').addEventListener('click', function () {
            this.classList.toggle('checked');
        });
        ingredientList.appendChild(el);
    });
}

async function loadKitchenInventory() {
    try {
        const res = await fetch(`${API_BASE}/api/kitchen`);
        if (!res.ok) return;
        const data = await res.json();
        const invList = document.querySelector('.inv-list');
        if (!invList || !data.items) return;
        invList.innerHTML = '';
        data.items.forEach(item => {
            const pct = Math.round((item.currentQty / item.maxQty) * 100);
            const level = pct > 60 ? 'high' : pct > 30 ? 'med' : 'low';
            const li = document.createElement('li');
            li.className = 'inv-item';
            li.innerHTML = `
        <div class="inv-item-left"><span class="inv-item-icon">${item.icon}</span><span class="inv-item-name">${item.name}</span></div>
        <span class="inv-item-qty">${item.displayQty}</span>
        <div class="inv-bar-wrap"><div class="inv-bar ${level}" style="width:${pct}%"></div></div>
      `;
            invList.appendChild(li);
        });
    } catch { /* use static fallback */ }
}

async function loadMarketData() {
    try {
        const res = await fetch(`${API_BASE}/api/market`);
        if (!res.ok) return;
        const data = await res.json();
        const insightCards = document.querySelectorAll('.insight-card');
        if (data.insights && insightCards.length >= 3) {
            data.insights.forEach((insight, i) => {
                if (insightCards[i]) {
                    insightCards[i].querySelector('h4').textContent = insight.title;
                    insightCards[i].querySelector('p').textContent = insight.description;
                    insightCards[i].querySelector('.insight-value').textContent = insight.value;
                }
            });
        }
    } catch { /* use static fallback */ }
}

async function loadGamification() {
    try {
        const res = await fetch(`${API_BASE}/api/gamification`);
        if (!res.ok) return;
        const data = await res.json();
        if (data.stats) {
            const cards = document.querySelectorAll('.gamify-card .gamify-value');
            const vals = [
                { v: data.stats.totalSavings, pre: '₹' },
                { v: data.stats.smartDecisions, pre: '' },
                { v: data.stats.streak, pre: '' },
                { v: data.stats.xp, pre: '' }
            ];
            cards.forEach((card, i) => {
                if (vals[i]) card.setAttribute('data-count', vals[i].v);
            });
        }
    } catch { /* use static fallback */ }
}

async function loadSmartCart() {
    try {
        const res = await fetch(`${API_BASE}/api/smart-cart`);
        if (!res.ok) return;
        const data = await res.json();
        if (data.totalSaved) {
            const savingsEl = document.querySelector('.optimize-savings-value');
            if (savingsEl) savingsEl.textContent = '₹' + data.totalSaved;
        }
    } catch { /* use static fallback */ }
}

// ── Scanner Functionality ──
function initScanner() {
    const dropZone = document.getElementById('scannerDropZone');
    const textarea = document.getElementById('scannerTextarea');
    const scanBtn = document.getElementById('scanListBtn');
    const clearBtn = document.getElementById('clearScanBtn');
    const fileInput = document.getElementById('scannerFileInput');
    const resultsDiv = document.getElementById('scannerResults');
    if (!dropZone || !textarea || !scanBtn) return;

    // Drag and drop
    ['dragenter', 'dragover'].forEach(evt => {
        dropZone.addEventListener(evt, (e) => { e.preventDefault(); dropZone.classList.add('dragover'); });
    });
    ['dragleave', 'drop'].forEach(evt => {
        dropZone.addEventListener(evt, (e) => { e.preventDefault(); dropZone.classList.remove('dragover'); });
    });
    dropZone.addEventListener('drop', (e) => {
        const file = e.dataTransfer.files[0];
        if (file) handleFile(file);
    });

    // File input change
    if (fileInput) {
        fileInput.addEventListener('change', (e) => {
            if (e.target.files[0]) handleFile(e.target.files[0]);
        });
    }

    function handleFile(file) {
        if (file.type.startsWith('text')) {
            const reader = new FileReader();
            reader.onload = (e) => { textarea.value = e.target.result; };
            reader.readAsText(file);
        } else if (file.type.startsWith('image')) {
            // Simulate OCR for demo
            textarea.value = 'Milk 1L\nEggs 12 pcs\nRice 5kg\nOnions 2kg\nButter 500g\nTomatoes 1kg\nPaneer 200g';
            scanList();
        }
    }

    // Scan button
    scanBtn.addEventListener('click', scanList);

    // Clear button
    if (clearBtn) {
        clearBtn.addEventListener('click', () => {
            textarea.value = '';
            resultsDiv.innerHTML = `
        <div class="scanner-placeholder">
          <span class="scanner-placeholder-icon">🛒</span>
          <p>Your scanned items will appear here.<br/>Try scanning a list to see AI-matched products!</p>
        </div>
      `;
        });
    }

    async function scanList() {
        const text = textarea.value.trim();
        if (!text) return;

        // Show scanning animation
        resultsDiv.innerHTML = `
      <div class="scanner-results-header">
        <h3>🔍 Scanning...</h3>
      </div>
      <div class="scanning-line"></div>
      <div class="scanning-line" style="animation-delay:0.3s"></div>
      <div class="scanning-line" style="animation-delay:0.6s"></div>
    `;

        try {
            const res = await fetch(`${API_BASE}/api/scan`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ text })
            });
            if (res.ok) {
                const data = await res.json();
                renderScanResults(data);
            } else {
                renderLocalScanResults(text);
            }
        } catch {
            renderLocalScanResults(text);
        }
    }

    function renderScanResults(data) {
        let html = `
      <div class="scanner-results-header">
        <h3>✅ AI-Matched Products</h3>
        <span class="scanner-results-count">${data.items.length} items found</span>
      </div>
    `;
        data.items.forEach((item, i) => {
            html += `
        <div class="scanner-item" style="opacity:0;animation:fadeInUp 0.4s ease ${i * 0.08}s forwards">
          <div class="scanner-item-icon">${item.icon || '📦'}</div>
          <div class="scanner-item-info">
            <div class="scanner-item-name">${item.name}</div>
            <div class="scanner-item-detail">${item.brand} · ${item.platform}</div>
          </div>
          <span class="scanner-item-price">₹${item.price}</span>
          <span class="scanner-item-added">✓ Added</span>
        </div>
      `;
        });
        html += `
      <div class="scanner-total">
        <span class="scanner-total-label">Estimated Total</span>
        <span class="scanner-total-value">₹${data.totalPrice}</span>
      </div>
    `;
        resultsDiv.innerHTML = html;
    }

    function renderLocalScanResults(text) {
        const lines = text.split('\n').filter(l => l.trim());
        const icons = ['🥛', '🥚', '🍚', '🧅', '🧈', '🍅', '🧀', '🫒', '🌶️', '🥣'];
        const brands = ['Amul', 'Tata', 'India Gate', 'Fresh', 'Organic', 'MDH', 'Kissan', 'Fortune'];
        const platforms = ['Blinkit', 'BigBasket', 'Zepto'];
        const items = lines.map((line, i) => ({
            name: line.trim(),
            icon: icons[i % icons.length],
            brand: brands[i % brands.length],
            platform: platforms[i % platforms.length],
            price: Math.floor(Math.random() * 200 + 20)
        }));
        const totalPrice = items.reduce((s, i) => s + i.price, 0);
        renderScanResults({ items, totalPrice });
    }
}

// ── Init ──
document.addEventListener('DOMContentLoaded', () => {
    buildHeroChart();

    // Add CSS animation keyframe
    const style = document.createElement('style');
    style.textContent = `
    @keyframes fadeInUp {
      from { opacity: 0; transform: translateY(20px); }
      to { opacity: 1; transform: translateY(0); }
    }
  `;
    document.head.appendChild(style);

    // Load data from backend API (graceful fallback to static content)
    loadKitchenInventory();
    loadMarketData();
    loadGamification();
    loadSmartCart();
    initScanner();

    // Smooth scroll for nav links
    document.querySelectorAll('a[href^="#"]').forEach(a => {
        a.addEventListener('click', (e) => {
            const target = document.querySelector(a.getAttribute('href'));
            if (target) {
                e.preventDefault();
                target.scrollIntoView({ behavior: 'smooth', block: 'start' });
            }
        });
    });
});
