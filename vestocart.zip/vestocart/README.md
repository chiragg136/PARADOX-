# 🛒 VestoCart — AI Grocery Intelligence Engine

A full-stack web application that uses AI to build the smartest grocery shopping cart.

## 📁 Project Structure

```
vestocart/
├── backend/                 # Express.js REST API Server
│   ├── server.js            # Entry point — mounts middleware & routes
│   ├── .env                 # Environment config (PORT, CORS)
│   ├── package.json         # Backend dependencies
│   ├── data/
│   │   └── store.js         # In-memory data store
│   ├── middleware/
│   │   └── logger.js        # Custom request logger
│   └── routes/
│       ├── kitchen.js       # Kitchen inventory CRUD
│       ├── recipes.js       # Recipes & Dish-to-Cart
│       ├── cart.js           # Smart Cart operations
│       ├── products.js      # Product catalog
│       ├── market.js        # Market intelligence
│       ├── swarm.js         # Swarm (community) intelligence
│       ├── gamification.js  # XP, levels, VestroScore
│       └── scanner.js       # Grocery list scanner
│
├── frontend/                # Static Frontend (HTML/CSS/JS)
│   ├── index.html           # Main HTML page
│   ├── package.json         # Frontend dev server
│   ├── css/
│   │   └── styles.css       # Stylesheet
│   └── js/
│       └── app.js           # Frontend logic & API calls
│
└── README.md                # This file
```

## 🚀 Quick Start

### 1. Start the Backend API
```bash
cd backend
npm install
npm start
```
The API server starts at **http://localhost:3000**.

### 2. Start the Frontend Dev Server
```bash
cd frontend
npx live-server --port=5500
```
The frontend opens at **http://localhost:5500** and connects to the backend API.

---

## 📡 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/health` | Health check & route list |
| `GET` | `/api/kitchen` | Get kitchen inventory |
| `POST` | `/api/kitchen` | Add kitchen item |
| `PUT` | `/api/kitchen/:id` | Update kitchen item |
| `DELETE` | `/api/kitchen/:id` | Delete kitchen item |
| `GET` | `/api/recipes` | List all recipes |
| `GET` | `/api/dish-to-cart?dish=...` | Get ingredients for a dish |
| `GET` | `/api/products` | List products (filter/sort) |
| `GET` | `/api/products/:id` | Get product details |
| `GET` | `/api/smart-cart` | Get smart cart |
| `POST` | `/api/smart-cart/add` | Add product to cart |
| `POST` | `/api/smart-cart/remove` | Remove product from cart |
| `POST` | `/api/smart-cart/optimize` | AI-optimize the cart |
| `GET` | `/api/market` | Get market intelligence |
| `GET` | `/api/market/predict/:item` | Predict price for item |
| `GET` | `/api/swarm` | Get community trends |
| `GET` | `/api/gamification` | Get gamification stats |
| `POST` | `/api/gamification/earn-xp` | Earn experience points |
| `GET` | `/api/gamification/vestro-score/:id` | Get VestroScore |
| `POST` | `/api/scan` | Scan a grocery list |

## 🔧 Architecture

- **Frontend** — Vanilla HTML/CSS/JS served on port 5500
- **Backend** — Express.js REST API on port 3000
- **Data** — In-memory store (can be swapped for MongoDB/PostgreSQL)
- **Communication** — Frontend calls backend via `fetch()` with CORS enabled

## 📌 Key Features

- 🧬 **Kitchen Twin** — Digital pantry inventory with AI tracking
- 🌐 **Swarm Intelligence** — Community-powered shopping recommendations
- ⚡ **Market Prediction** — AI price forecasting for optimal buy timing
- 🧩 **Smart Cart** — Multi-platform cart optimization
- 🍲 **Dish-to-Cart** — Recipe-based ingredient shopping
- 🏆 **Gamification** — XP, levels, and badges for smart shopping
- 📷 **Scanner** — Grocery list scanning with product matching
