// ═══════════════════════════════════════════════════
// VestoCart — In-Memory Data Store
// ═══════════════════════════════════════════════════

const data = {
    // ── Kitchen Inventory ──
    kitchen: [
        { id: 1, name: "Milk", icon: "🥛", currentQty: 1.2, maxQty: 2, unit: "L", displayQty: "1.2L left", category: "dairy", expiresIn: 3 },
        { id: 2, name: "Basmati Rice", icon: "🍚", currentQty: 400, maxQty: 5000, unit: "g", displayQty: "400g left", category: "grains", expiresIn: 90 },
        { id: 3, name: "Eggs", icon: "🥚", currentQty: 3, maxQty: 12, unit: "pcs", displayQty: "3 left", category: "dairy", expiresIn: 7 },
        { id: 4, name: "Olive Oil", icon: "🫒", currentQty: 200, maxQty: 500, unit: "ml", displayQty: "200ml left", category: "oils", expiresIn: 120 },
        { id: 5, name: "Butter", icon: "🧈", currentQty: 50, maxQty: 500, unit: "g", displayQty: "50g left", category: "dairy", expiresIn: 14 },
        { id: 6, name: "Onions", icon: "🧅", currentQty: 800, maxQty: 2000, unit: "g", displayQty: "800g left", category: "vegetables", expiresIn: 21 },
        { id: 7, name: "Tomatoes", icon: "🍅", currentQty: 300, maxQty: 1000, unit: "g", displayQty: "300g left", category: "vegetables", expiresIn: 5 },
        { id: 8, name: "Garlic", icon: "🧄", currentQty: 100, maxQty: 250, unit: "g", displayQty: "100g left", category: "vegetables", expiresIn: 30 },
        { id: 9, name: "Cumin Seeds", icon: "🌿", currentQty: 80, maxQty: 200, unit: "g", displayQty: "80g left", category: "spices", expiresIn: 180 },
        { id: 10, name: "Yogurt", icon: "🥣", currentQty: 150, maxQty: 500, unit: "g", displayQty: "150g left", category: "dairy", expiresIn: 4 }
    ],

    // ── Recipes (Dish-to-Cart) ──
    recipes: {
        "Paneer Butter Masala": {
            servings: 4, prepTime: "35 min", cuisine: "North Indian",
            ingredients: [
                { name: "Paneer (200g)", brand: "Fresh block", price: 89, inKitchen: false },
                { name: "Butter (100g)", brand: "Amul salted", price: 56, inKitchen: true },
                { name: "Tomato Puree (400g)", brand: "Kissan", price: 45, inKitchen: false },
                { name: "Cream (200ml)", brand: "Amul fresh", price: 35, inKitchen: false },
                { name: "Garam Masala (50g)", brand: "MDH", price: 42, inKitchen: true },
                { name: "Kasuri Methi (25g)", brand: "Organic", price: 28, inKitchen: false },
                { name: "Ginger Garlic Paste (50g)", brand: "Smith & Jones", price: 22, inKitchen: true },
                { name: "Red Chili Powder (20g)", brand: "MDH", price: 15, inKitchen: true },
                { name: "Salt", brand: "Tata", price: 0, inKitchen: true }
            ]
        },
        "Chicken Biryani": {
            servings: 6, prepTime: "60 min", cuisine: "Hyderabadi",
            ingredients: [
                { name: "Chicken (500g)", brand: "Fresh", price: 210, inKitchen: false },
                { name: "Basmati Rice (1kg)", brand: "India Gate", price: 145, inKitchen: true },
                { name: "Onions (500g)", brand: "Fresh", price: 25, inKitchen: true },
                { name: "Yogurt (200g)", brand: "Amul", price: 30, inKitchen: true },
                { name: "Biryani Masala (50g)", brand: "Shan", price: 65, inKitchen: false },
                { name: "Saffron (1g)", brand: "Kashmir", price: 120, inKitchen: false },
                { name: "Mint Leaves (bunch)", brand: "Organic", price: 15, inKitchen: false },
                { name: "Ghee (100g)", brand: "Amul", price: 58, inKitchen: false },
                { name: "Bay Leaves (5g)", brand: "Organic", price: 10, inKitchen: true },
                { name: "Green Cardamom (10g)", brand: "Organic", price: 35, inKitchen: true },
                { name: "Cinnamon Sticks (10g)", brand: "Organic", price: 20, inKitchen: true },
                { name: "Ginger Garlic Paste (50g)", brand: "Smith & Jones", price: 22, inKitchen: true },
                { name: "Green Chilies (50g)", brand: "Fresh", price: 8, inKitchen: true },
                { name: "Lemon (2 pcs)", brand: "Fresh", price: 10, inKitchen: false }
            ]
        },
        "Masala Dosa": {
            servings: 4, prepTime: "25 min", cuisine: "South Indian",
            ingredients: [
                { name: "Dosa Batter (500g)", brand: "iD Fresh", price: 55, inKitchen: false },
                { name: "Potatoes (500g)", brand: "Fresh", price: 20, inKitchen: true },
                { name: "Onions (250g)", brand: "Fresh", price: 12, inKitchen: true },
                { name: "Mustard Seeds (50g)", brand: "Organic", price: 18, inKitchen: true },
                { name: "Curry Leaves (bunch)", brand: "Fresh", price: 10, inKitchen: false },
                { name: "Oil (200ml)", brand: "Sunflower", price: 35, inKitchen: true },
                { name: "Turmeric (20g)", brand: "MDH", price: 12, inKitchen: true },
                { name: "Green Chilies (30g)", brand: "Fresh", price: 5, inKitchen: true }
            ]
        },
        "Dal Makhani": {
            servings: 4, prepTime: "45 min", cuisine: "Punjabi",
            ingredients: [
                { name: "Black Urad Dal (250g)", brand: "Tata", price: 68, inKitchen: false },
                { name: "Rajma (100g)", brand: "Tata", price: 35, inKitchen: false },
                { name: "Butter (100g)", brand: "Amul", price: 56, inKitchen: true },
                { name: "Cream (200ml)", brand: "Amul", price: 35, inKitchen: false },
                { name: "Tomatoes (300g)", brand: "Fresh", price: 18, inKitchen: true },
                { name: "Ginger Garlic Paste (100g)", brand: "Smith & Jones", price: 32, inKitchen: true },
                { name: "Red Chili Powder (20g)", brand: "MDH", price: 15, inKitchen: true },
                { name: "Garam Masala (20g)", brand: "MDH", price: 18, inKitchen: true },
                { name: "Cumin Seeds (10g)", brand: "Organic", price: 8, inKitchen: true },
                { name: "Bay Leaves (5g)", brand: "Organic", price: 10, inKitchen: true },
                { name: "Kasuri Methi (10g)", brand: "Organic", price: 12, inKitchen: false }
            ]
        },
        "Chole Bhature": {
            servings: 4, prepTime: "50 min", cuisine: "Punjabi",
            ingredients: [
                { name: "Chickpeas (250g)", brand: "Tata", price: 45, inKitchen: false },
                { name: "All Purpose Flour (500g)", brand: "Aashirvaad", price: 35, inKitchen: false },
                { name: "Yogurt (100g)", brand: "Amul", price: 20, inKitchen: true },
                { name: "Onions (300g)", brand: "Fresh", price: 15, inKitchen: true },
                { name: "Tomatoes (300g)", brand: "Fresh", price: 18, inKitchen: true },
                { name: "Chole Masala (50g)", brand: "MDH", price: 40, inKitchen: false },
                { name: "Ginger (50g)", brand: "Fresh", price: 8, inKitchen: true },
                { name: "Oil (500ml)", brand: "Sunflower", price: 65, inKitchen: true }
            ]
        },
        "Aloo Gobi": {
            servings: 3, prepTime: "30 min", cuisine: "North Indian",
            ingredients: [
                { name: "Cauliflower (500g)", brand: "Fresh", price: 30, inKitchen: false },
                { name: "Potatoes (400g)", brand: "Fresh", price: 18, inKitchen: true },
                { name: "Onions (200g)", brand: "Fresh", price: 10, inKitchen: true },
                { name: "Tomatoes (200g)", brand: "Fresh", price: 12, inKitchen: true },
                { name: "Turmeric (10g)", brand: "MDH", price: 8, inKitchen: true },
                { name: "Cumin Seeds (10g)", brand: "Organic", price: 8, inKitchen: true },
                { name: "Garam Masala (10g)", brand: "MDH", price: 10, inKitchen: true },
                { name: "Oil (50ml)", brand: "Mustard", price: 12, inKitchen: true }
            ]
        }
    },

    // ── Products (Smart Cart) ──
    products: [
        { id: 1, name: "Organic Basmati Rice", brand: "India Gate", weight: "5kg", platform: "Blinkit", delivery: "12 min", price: 389, originalPrice: 449, vestroScore: 9.4, icon: "🍚", category: "grains" },
        { id: 2, name: "Extra Virgin Olive Oil", brand: "Figaro", weight: "500ml", platform: "BigBasket", delivery: "30 min", price: 445, originalPrice: 520, vestroScore: 8.7, icon: "🫒", category: "oils" },
        { id: 3, name: "Farm Fresh Eggs", brand: "Country Delight", weight: "12 pcs", platform: "Zepto", delivery: "8 min", price: 94, originalPrice: 110, vestroScore: 9.1, icon: "🥚", category: "dairy" },
        { id: 4, name: "Amul Butter", brand: "Amul", weight: "500g", platform: "Blinkit", delivery: "10 min", price: 270, originalPrice: 290, vestroScore: 9.3, icon: "🧈", category: "dairy" },
        { id: 5, name: "Tata Sampann Chana Dal", brand: "Tata", weight: "1kg", platform: "BigBasket", delivery: "25 min", price: 135, originalPrice: 160, vestroScore: 8.9, icon: "🫘", category: "pulses" },
        { id: 6, name: "MDH Garam Masala", brand: "MDH", weight: "100g", platform: "Zepto", delivery: "9 min", price: 82, originalPrice: 95, vestroScore: 9.0, icon: "🌶️", category: "spices" },
        { id: 7, name: "Full Cream Milk", brand: "Amul", weight: "1L", platform: "Blinkit", delivery: "10 min", price: 66, originalPrice: 68, vestroScore: 9.5, icon: "🥛", category: "dairy" },
        { id: 8, name: "Whole Wheat Atta", brand: "Aashirvaad", weight: "5kg", platform: "BigBasket", delivery: "35 min", price: 245, originalPrice: 280, vestroScore: 9.2, icon: "🌾", category: "grains" },
        { id: 9, name: "Sunflower Oil", brand: "Fortune", weight: "1L", platform: "Zepto", delivery: "11 min", price: 145, originalPrice: 170, vestroScore: 8.6, icon: "🌻", category: "oils" }
    ],

    // ── Market Intelligence ──
    market: {
        predictions: [
            { item: "Basmati Rice (5kg)", currentPrice: 389, predictedPrice: 320, change: -18, buyWindow: "5 days", confidence: 87 },
            { item: "Olive Oil (500ml)", currentPrice: 445, predictedPrice: 410, change: -8, buyWindow: "2 days", confidence: 72 },
            { item: "Eggs (12 pcs)", currentPrice: 94, predictedPrice: 105, change: 12, buyWindow: "Now", confidence: 91 },
            { item: "Butter (500g)", currentPrice: 270, predictedPrice: 255, change: -6, buyWindow: "3 days", confidence: 68 }
        ],
        insights: [
            { title: "Price Drop Predicted", description: "Rice prices expected to drop", value: "-18% in 5 days", type: "drop" },
            { title: "Best Buy Window", description: "Optimal purchase timing", value: "Tue 8–11 AM", type: "timing" },
            { title: "Demand Surge Alert", description: "Cooking oil demand rising", value: "+24% demand", type: "surge" }
        ],
        trends: [
            { item: "Rice", direction: "down", percentage: 18, timeframe: "5 days" },
            { item: "Cooking Oil", direction: "up", percentage: 24, timeframe: "2 weeks" },
            { item: "Eggs", direction: "up", percentage: 12, timeframe: "3 days" },
            { item: "Milk", direction: "stable", percentage: 1, timeframe: "1 week" }
        ]
    },

    // ── Swarm Intelligence ──
    swarm: {
        trending: [
            { product: "Organic Basmati Rice", buyers: 2100, region: "Delhi NCR", trend: "rising" },
            { product: "Amul Butter", buyers: 1850, region: "Mumbai", trend: "stable" },
            { product: "Farm Fresh Eggs", buyers: 3200, region: "Bangalore", trend: "rising" },
            { product: "MDH Garam Masala", buyers: 980, region: "Hyderabad", trend: "rising" }
        ],
        communityPicks: [
            { product: "India Gate Basmati", reason: "Best price-quality ratio", votes: 4250 },
            { product: "Amul Gold Milk", reason: "Consistent quality", votes: 3800 },
            { product: "Figaro Olive Oil", reason: "Authentic imported", votes: 2100 }
        ]
    },

    // ── Gamification ──
    gamification: {
        stats: { totalSavings: 12480, smartDecisions: 347, streak: 18, xp: 4250 },
        level: { current: 4, name: "Deal Hunter", nextLevel: "Cart Master", xpNeeded: 6250 },
        badges: [
            { name: "First Smart Cart", icon: "🛒", earned: true },
            { name: "Savings Streak 7", icon: "🔥", earned: true },
            { name: "Swarm Contributor", icon: "🌐", earned: true },
            { name: "Kitchen Master", icon: "🧬", earned: false },
            { name: "Price Prophet", icon: "📈", earned: false }
        ],
        levels: [
            { level: 1, name: "Beginner", icon: "🌱", xpRequired: 0 },
            { level: 2, name: "Smart Buyer", icon: "🛒", xpRequired: 500 },
            { level: 3, name: "Savings Pro", icon: "💎", xpRequired: 1500 },
            { level: 4, name: "Deal Hunter", icon: "🔥", xpRequired: 3000 },
            { level: 5, name: "Cart Master", icon: "👑", xpRequired: 6250 }
        ]
    },

    // ── Shopping Cart ──
    cart: []
};

module.exports = data;
