// ═══════════════════════════════════════
// Gamification Routes
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const data = require('../data/store');

// GET gamification stats
router.get('/', (req, res) => {
    res.json({
        stats: data.gamification.stats,
        level: data.gamification.level,
        badges: data.gamification.badges,
        levels: data.gamification.levels,
        progressPercent: Math.round(
            (data.gamification.stats.xp / data.gamification.level.xpNeeded) * 100
        )
    });
});

// POST earn XP
router.post('/earn-xp', (req, res) => {
    const { amount, reason } = req.body;
    const xp = parseInt(amount) || 10;
    data.gamification.stats.xp += xp;

    // Level up check
    const nextLevel = data.gamification.levels.find(l =>
        l.xpRequired > data.gamification.stats.xp
    );
    const currentLevel = data.gamification.levels
        .filter(l => l.xpRequired <= data.gamification.stats.xp)
        .pop();

    if (currentLevel) {
        data.gamification.level.current = currentLevel.level;
        data.gamification.level.name = currentLevel.name;
    }
    if (nextLevel) {
        data.gamification.level.nextLevel = nextLevel.name;
        data.gamification.level.xpNeeded = nextLevel.xpRequired;
    }

    res.json({
        xpEarned: xp,
        reason: reason || 'action',
        totalXp: data.gamification.stats.xp,
        level: data.gamification.level
    });
});

// GET VestroScore for a product
router.get('/vestro-score/:productId', (req, res) => {
    const product = data.products.find(p => p.id === parseInt(req.params.productId));
    if (!product) return res.status(404).json({ error: 'Product not found' });

    const priceScore = Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100 + 50);
    const ratingScore = Math.round(product.vestroScore * 10);
    const communityTrust = Math.round(85 + Math.random() * 10);
    const deliveryScore = product.delivery.includes('8') || product.delivery.includes('10') ? 95 : 80;
    const overall = Math.round(
        (priceScore * 0.25 + ratingScore * 0.3 + communityTrust * 0.25 + deliveryScore * 0.2)
    );

    res.json({
        productId: product.id,
        productName: product.name,
        overallScore: Math.min(overall, 99),
        breakdown: { priceValue: priceScore, ratingScore, communityTrust, deliveryScore }
    });
});

module.exports = router;
