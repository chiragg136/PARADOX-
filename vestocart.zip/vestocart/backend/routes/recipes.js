// ═══════════════════════════════════════
// Recipes & Dish-to-Cart Routes
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const data = require('../data/store');

// GET dish-to-cart ingredients
router.get('/dish-to-cart', (req, res) => {
    const dishName = req.query.dish;
    if (!dishName) return res.status(400).json({ error: 'dish query parameter required' });

    const recipe = data.recipes[dishName];
    if (!recipe) {
        const available = Object.keys(data.recipes);
        return res.status(404).json({ error: 'Recipe not found', available });
    }

    // Cross-reference with kitchen to mark what user already has
    const ingredients = recipe.ingredients.map(ing => {
        const kitchenItem = data.kitchen.find(k =>
            ing.name.toLowerCase().includes(k.name.toLowerCase()) ||
            k.name.toLowerCase().includes(ing.name.split('(')[0].trim().toLowerCase())
        );
        return {
            ...ing,
            inKitchen: kitchenItem ? (kitchenItem.currentQty / kitchenItem.maxQty) > 0.15 : ing.inKitchen
        };
    });

    const totalCost = ingredients.reduce((sum, i) => sum + i.price, 0);
    const needToBuy = ingredients.filter(i => !i.inKitchen);
    const costToBuy = needToBuy.reduce((sum, i) => sum + i.price, 0);

    res.json({
        dish: dishName,
        servings: recipe.servings,
        prepTime: recipe.prepTime,
        cuisine: recipe.cuisine,
        ingredients,
        totalCost,
        itemsNeeded: needToBuy.length,
        costToBuy
    });
});

// GET all recipes
router.get('/recipes', (req, res) => {
    const list = Object.entries(data.recipes).map(([name, r]) => ({
        name,
        servings: r.servings,
        prepTime: r.prepTime,
        cuisine: r.cuisine,
        ingredientCount: r.ingredients.length,
        totalCost: r.ingredients.reduce((s, i) => s + i.price, 0)
    }));
    res.json({ recipes: list });
});

module.exports = router;
