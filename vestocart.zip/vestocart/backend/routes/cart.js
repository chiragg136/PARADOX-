// ═══════════════════════════════════════
// Smart Cart Routes
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const data = require('../data/store');

// GET smart cart
router.get('/', (req, res) => {
    const cartItems = data.cart.length > 0 ? data.cart : data.products.slice(0, 3);
    const totalPrice = cartItems.reduce((s, i) => s + i.price, 0);
    const totalOriginal = cartItems.reduce((s, i) => s + (i.originalPrice || i.price), 0);
    const totalSaved = totalOriginal - totalPrice;
    res.json({
        items: cartItems,
        totalPrice,
        totalOriginal,
        totalSaved,
        platforms: [...new Set(cartItems.map(i => i.platform))],
        avgvestroScore: +(cartItems.reduce((s, i) => s + (i.vestroScore || 0), 0) / cartItems.length).toFixed(1)
    });
});

// POST add item to cart
router.post('/add', (req, res) => {
    const { productId } = req.body;
    const product = data.products.find(p => p.id === productId);
    if (!product) return res.status(404).json({ error: 'Product not found' });
    data.cart.push({ ...product });
    res.json({ success: true, cart: data.cart });
});

// POST remove item from cart
router.post('/remove', (req, res) => {
    const { productId } = req.body;
    const idx = data.cart.findIndex(p => p.id === productId);
    if (idx === -1) return res.status(404).json({ error: 'Item not in cart' });
    data.cart.splice(idx, 1);
    res.json({ success: true, cart: data.cart });
});

// POST optimize cart
router.post('/optimize', (req, res) => {
    const optimized = [...(data.cart.length > 0 ? data.cart : data.products)];
    optimized.sort((a, b) => (b.vestroScore / b.price) - (a.vestroScore / a.price));
    const totalPrice = optimized.reduce((s, i) => s + i.price, 0);
    const totalOriginal = optimized.reduce((s, i) => s + (i.originalPrice || i.price), 0);
    res.json({
        optimizedCart: optimized.slice(0, 6),
        totalPrice,
        totalSaved: totalOriginal - totalPrice,
        optimizationScore: 94,
        strategy: "Balanced cost × quality × delivery speed"
    });
});

module.exports = router;
