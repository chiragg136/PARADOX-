// ═══════════════════════════════════════
// Swarm Intelligence Routes
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const data = require('../data/store');

// GET swarm data
router.get('/', (req, res) => {
    res.json({
        trending: data.swarm.trending,
        communityPicks: data.swarm.communityPicks,
        activeBuyers: data.swarm.trending.reduce((s, t) => s + t.buyers, 0)
    });
});

module.exports = router;
