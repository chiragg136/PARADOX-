// ═══════════════════════════════════════
// Kitchen Inventory Routes
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const data = require('../data/store');

// GET all kitchen items
router.get('/', (req, res) => {
    const items = data.kitchen.map(item => ({
        ...item,
        percentLeft: Math.round((item.currentQty / item.maxQty) * 100),
        needsRefill: (item.currentQty / item.maxQty) < 0.25
    }));
    const refillNeeded = items.filter(i => i.needsRefill);
    res.json({ items, refillNeeded, totalItems: items.length });
});

// GET single kitchen item
router.get('/:id', (req, res) => {
    const item = data.kitchen.find(i => i.id === parseInt(req.params.id));
    if (!item) return res.status(404).json({ error: 'Item not found' });
    res.json(item);
});

// POST new kitchen item
router.post('/', (req, res) => {
    const { name, icon, currentQty, maxQty, unit, category } = req.body;
    if (!name || !currentQty || !maxQty) {
        return res.status(400).json({ error: 'name, currentQty, and maxQty are required' });
    }
    const newItem = {
        id: data.kitchen.length + 1,
        name,
        icon: icon || '📦',
        currentQty: parseFloat(currentQty),
        maxQty: parseFloat(maxQty),
        unit: unit || 'g',
        displayQty: `${currentQty}${unit || 'g'} left`,
        category: category || 'other',
        expiresIn: 30
    };
    data.kitchen.push(newItem);
    res.status(201).json(newItem);
});

// PUT update kitchen item
router.put('/:id', (req, res) => {
    const item = data.kitchen.find(i => i.id === parseInt(req.params.id));
    if (!item) return res.status(404).json({ error: 'Item not found' });
    const { currentQty, maxQty, name, icon } = req.body;
    if (currentQty !== undefined) {
        item.currentQty = parseFloat(currentQty);
        item.displayQty = `${currentQty}${item.unit} left`;
    }
    if (maxQty !== undefined) item.maxQty = parseFloat(maxQty);
    if (name) item.name = name;
    if (icon) item.icon = icon;
    res.json(item);
});

// DELETE kitchen item
router.delete('/:id', (req, res) => {
    const idx = data.kitchen.findIndex(i => i.id === parseInt(req.params.id));
    if (idx === -1) return res.status(404).json({ error: 'Item not found' });
    data.kitchen.splice(idx, 1);
    res.json({ success: true });
});

module.exports = router;
