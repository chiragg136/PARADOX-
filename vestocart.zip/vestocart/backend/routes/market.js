// ═══════════════════════════════════════
// Market Intelligence Routes
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const data = require('../data/store');

// GET all market data
router.get('/', (req, res) => {
    res.json({
        predictions: data.market.predictions,
        insights: data.market.insights,
        trends: data.market.trends
    });
});

// GET prediction for specific item
router.get('/predict/:item', (req, res) => {
    const itemName = decodeURIComponent(req.params.item).toLowerCase();
    const prediction = data.market.predictions.find(p =>
        p.item.toLowerCase().includes(itemName)
    );
    if (!prediction) return res.status(404).json({ error: 'No prediction available for this item' });
    res.json(prediction);
});

module.exports = router;
