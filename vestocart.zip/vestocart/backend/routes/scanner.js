// ═══════════════════════════════════════
// Scanner Routes
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const data = require('../data/store');

// POST scan a grocery list
router.post('/', (req, res) => {
    const { text } = req.body;
    if (!text) return res.status(400).json({ error: 'text field required' });

    const lines = text.split('\n').map(l => l.trim()).filter(l => l.length > 0);

    const icons = {
        milk: '🥛', egg: '🥚', rice: '🍚', onion: '🧅', butter: '🧈',
        tomato: '🍅', paneer: '🧀', oil: '🫒', chili: '🌶️', sugar: '🍬',
        salt: '🧂', flour: '🌾', dal: '🫘', chicken: '🍗', yogurt: '🥣',
        cream: '🥛', potato: '🥔', garlic: '🧄', ginger: '🫚', lemon: '🍋'
    };
    const platforms = ['Blinkit', 'BigBasket', 'Zepto'];

    const items = lines.map((line, i) => {
        const lower = line.toLowerCase();

        // Try to match with product database
        const matched = data.products.find(p =>
            lower.includes(p.name.toLowerCase().split(' ')[0]) ||
            p.name.toLowerCase().includes(lower.split(' ')[0])
        );

        // Try to find icon
        let icon = '📦';
        for (const [key, emoji] of Object.entries(icons)) {
            if (lower.includes(key)) { icon = emoji; break; }
        }

        return {
            name: matched ? matched.name : line,
            icon: matched ? matched.icon : icon,
            brand: matched ? matched.brand : ['Amul', 'Tata', 'Fresh', 'Organic', 'MDH', 'Fortune'][i % 6],
            platform: matched ? matched.platform : platforms[i % 3],
            price: matched ? matched.price : Math.floor(Math.random() * 180 + 20),
            vestroScore: matched ? matched.vestroScore : +(Math.random() * 2 + 7.5).toFixed(1),
            delivery: matched ? matched.delivery : `${Math.floor(Math.random() * 20 + 8)} min`
        };
    });

    const totalPrice = items.reduce((s, i) => s + i.price, 0);
    res.json({
        items,
        totalPrice,
        itemCount: items.length,
        platforms: [...new Set(items.map(i => i.platform))]
    });
});

module.exports = router;
