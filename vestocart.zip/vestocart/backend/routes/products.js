// ═══════════════════════════════════════
// Products Routes
// ═══════════════════════════════════════

const express = require('express');
const router = express.Router();
const data = require('../data/store');

// GET all products (with filtering & sorting)
router.get('/', (req, res) => {
    let filtered = [...data.products];
    if (req.query.category) filtered = filtered.filter(p => p.category === req.query.category);
    if (req.query.platform) filtered = filtered.filter(p => p.platform === req.query.platform);
    if (req.query.sort === 'price') filtered.sort((a, b) => a.price - b.price);
    if (req.query.sort === 'vestro') filtered.sort((a, b) => b.vestroScore - a.vestroScore);
    if (req.query.search) {
        const q = req.query.search.toLowerCase();
        filtered = filtered.filter(p =>
            p.name.toLowerCase().includes(q) || p.brand.toLowerCase().includes(q)
        );
    }
    res.json({ products: filtered, total: filtered.length });
});

// GET single product
router.get('/:id', (req, res) => {
    const product = data.products.find(p => p.id === parseInt(req.params.id));
    if (!product) return res.status(404).json({ error: 'Product not found' });
    res.json(product);
});

module.exports = router;
