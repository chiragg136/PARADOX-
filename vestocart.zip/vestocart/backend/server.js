// ═══════════════════════════════════════════════════
// VestoCart — Backend API Server (Entry Point)
// ═══════════════════════════════════════════════════

require('dotenv').config();

const express = require('express');
const cors = require('cors');
const path = require('path');
const morgan = require('morgan');
const requestLogger = require('./middleware/logger');

// ── Import Route Modules ──
const kitchenRoutes = require('./routes/kitchen');
const recipesRoutes = require('./routes/recipes');
const cartRoutes = require('./routes/cart');
const productsRoutes = require('./routes/products');
const marketRoutes = require('./routes/market');
const swarmRoutes = require('./routes/swarm');
const gamificationRoutes = require('./routes/gamification');
const scannerRoutes = require('./routes/scanner');

// ── Initialize Express App ──
const app = express();
const PORT = process.env.PORT || 3000;

// ═══════════════════════════════════════
// MIDDLEWARE
// ═══════════════════════════════════════

// CORS — allow all origins in development, restrict in production
if (process.env.NODE_ENV === 'production') {
    app.use(cors({
        origin: process.env.CORS_ORIGIN || 'http://localhost:5500',
        methods: ['GET', 'POST', 'PUT', 'DELETE'],
        credentials: true
    }));
} else {
    app.use(cors()); // allow all origins in development
}

// Parse JSON request bodies
app.use(express.json());

// HTTP request logging (dev-friendly)
if (process.env.NODE_ENV !== 'production') {
    app.use(morgan('dev'));
}

// Custom request logger
app.use(requestLogger);

// ═══════════════════════════════════════
// API ROUTES
// ═══════════════════════════════════════

app.use('/api/kitchen', kitchenRoutes);
app.use('/api', recipesRoutes);        // mounts /api/dish-to-cart & /api/recipes
app.use('/api/smart-cart', cartRoutes);
app.use('/api/products', productsRoutes);
app.use('/api/market', marketRoutes);
app.use('/api/swarm', swarmRoutes);
app.use('/api/gamification', gamificationRoutes);
app.use('/api/scan', scannerRoutes);

// ── Health Check ──
app.get('/api/health', (req, res) => {
    res.json({
        status: 'ok',
        service: 'VestoCart API',
        version: '2.0.0',
        architecture: 'modular-backend',
        uptime: process.uptime(),
        routes: [
            'GET  /api/health',
            'GET  /api/kitchen',
            'POST /api/kitchen',
            'PUT  /api/kitchen/:id',
            'DEL  /api/kitchen/:id',
            'GET  /api/dish-to-cart?dish=...',
            'GET  /api/recipes',
            'GET  /api/products',
            'GET  /api/products/:id',
            'GET  /api/smart-cart',
            'POST /api/smart-cart/add',
            'POST /api/smart-cart/remove',
            'POST /api/smart-cart/optimize',
            'GET  /api/market',
            'GET  /api/market/predict/:item',
            'GET  /api/swarm',
            'GET  /api/gamification',
            'POST /api/gamification/earn-xp',
            'GET  /api/gamification/vestro-score/:id',
            'POST /api/scan'
        ]
    });
});

// ═══════════════════════════════════════
// SERVE FRONTEND (Static Files)
// ═══════════════════════════════════════

// Serve the frontend from ../frontend directory
const frontendPath = path.join(__dirname, '..', 'frontend');
app.use(express.static(frontendPath));

// SPA fallback — serve index.html for any non-API route
app.get('*', (req, res, next) => {
    if (req.path.startsWith('/api')) return next();
    res.sendFile(path.join(frontendPath, 'index.html'));
});

// ═══════════════════════════════════════
// ERROR HANDLING
// ═══════════════════════════════════════

// 404 handler (only for unmatched /api routes)
app.use((req, res) => {
    res.status(404).json({
        error: 'Not Found',
        message: `Route ${req.method} ${req.originalUrl} does not exist`,
        hint: 'Visit GET /api/health for a list of available routes'
    });
});

// Global error handler
app.use((err, req, res, next) => {
    console.error('\x1b[31m  ERROR:\x1b[0m', err.message);
    res.status(err.status || 500).json({
        error: err.message || 'Internal Server Error',
        ...(process.env.NODE_ENV !== 'production' && { stack: err.stack })
    });
});

// ═══════════════════════════════════════
// START SERVER
// ═══════════════════════════════════════

app.listen(PORT, () => {
    console.log(`\n  🛒 VestoCart — Full-Stack Server`);
    console.log(`  ══════════════════════════════════`);
    console.log(`  🌐 App:          http://localhost:${PORT}`);
    console.log(`  📡 API:          http://localhost:${PORT}/api/health`);
    console.log(`  📂 Frontend:     ${frontendPath}`);
    console.log(`  📡 Environment:  ${process.env.NODE_ENV || 'development'}`);
    console.log(`  ──────────────────────────────────`);
    console.log(`  📋 API Routes:`);
    console.log(`     GET  /api/health`);
    console.log(`     GET  /api/kitchen`);
    console.log(`     GET  /api/recipes`);
    console.log(`     GET  /api/dish-to-cart?dish=...`);
    console.log(`     GET  /api/products`);
    console.log(`     GET  /api/smart-cart`);
    console.log(`     GET  /api/market`);
    console.log(`     GET  /api/swarm`);
    console.log(`     GET  /api/gamification`);
    console.log(`     POST /api/scan`);
    console.log(`  ══════════════════════════════════\n`);
});
