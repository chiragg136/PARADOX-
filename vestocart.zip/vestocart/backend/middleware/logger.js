// ═══════════════════════════════════════
// Custom Request Logger Middleware
// ═══════════════════════════════════════

function requestLogger(req, res, next) {
    const start = Date.now();
    const timestamp = new Date().toISOString();

    // Capture the original end method to log after response is sent
    const originalEnd = res.end;
    res.end = function (...args) {
        const duration = Date.now() - start;
        const status = res.statusCode;
        const statusColor = status >= 400 ? '\x1b[31m' : status >= 300 ? '\x1b[33m' : '\x1b[32m';
        const reset = '\x1b[0m';

        console.log(
            `  ${statusColor}${req.method}${reset} ${req.originalUrl} → ${statusColor}${status}${reset} (${duration}ms)`
        );

        originalEnd.apply(res, args);
    };

    next();
}

module.exports = requestLogger;
