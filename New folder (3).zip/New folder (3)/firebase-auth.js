// --- "Real" Local Storage Database Backend ---
// This version uses standard global scope to avoid CORS issues on file:// protocol

window.VestoAuth = {
    // DB Simulation
    getUsers() {
        return JSON.parse(localStorage.getItem('vesto_users') || '[]');
    },
    getActiveUser() {
        return JSON.parse(localStorage.getItem('vesto_active_user') || 'null');
    },

    save(users, activeUser) {
        if (users) localStorage.setItem('vesto_users', JSON.stringify(users));
        localStorage.setItem('vesto_active_user', JSON.stringify(activeUser));
    },

    signUp(email, password) {
        let users = this.getUsers();
        if (users.find(u => u.email === email)) {
            throw new Error("User already exists!");
        }
        const newUser = {
            id: Date.now(),
            email,
            password,
            createdAt: new Date().toISOString(),
            cart: []
        };
        users.push(newUser);
        this.save(users, newUser);
        return newUser;
    },

    signIn(email, password) {
        const users = this.getUsers();
        const user = users.find(u => u.email === email && u.password === password);
        if (!user) {
            throw new Error("Invalid email or password!");
        }
        this.save(null, user);
        return user;
    },

    signOut() {
        this.save(null, null);
        window.location.href = 'login.html';
    },

    checkAuth() {
        const activeUser = this.getActiveUser();
        const isAuthPage = window.location.pathname.includes('login.html') || window.location.pathname.includes('signup.html');

        if (!activeUser && !isAuthPage) {
            window.location.href = 'login.html';
        }
        if (activeUser && isAuthPage) {
            window.location.href = 'index.html';
        }
    }
};

// Handle Form Submissions
document.addEventListener('DOMContentLoaded', () => {
    window.VestoAuth.checkAuth();

    const signupForm = document.getElementById('signupForm');
    const loginForm = document.getElementById('loginForm');

    if (signupForm) {
        signupForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = e.target.email.value;
            const pass = e.target.password.value;
            const confirm = e.target.confirmPassword.value;

            if (pass !== confirm) {
                alert("Passwords do not match!");
                return;
            }

            try {
                window.VestoAuth.signUp(email, pass);
                window.location.href = 'index.html';
            } catch (err) {
                alert(err.message);
            }
        });
    }

    if (loginForm) {
        loginForm.addEventListener('submit', (e) => {
            e.preventDefault();
            const email = e.target.email.value;
            const pass = e.target.password.value;

            try {
                window.VestoAuth.signIn(email, pass);
                window.location.href = 'index.html';
            } catch (err) {
                alert(err.message);
            }
        });
    }
});
